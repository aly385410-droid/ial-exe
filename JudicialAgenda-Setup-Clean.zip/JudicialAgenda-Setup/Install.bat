@echo off
title Judicial Electronic Assistant - Setup
echo.
echo  Installing the application...
echo  (No internet is needed for the quick install)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
