﻿param([switch]$Stage2)
$ErrorActionPreference = 'Continue'
$appName = 'المساعد القضائي الإلكتروني'
$dest = Join-Path $env:LOCALAPPDATA 'JudicialAgendaApp'
$lite = Join-Path $env:LOCALAPPDATA 'JudicialAssistantLite'
$liteData = Join-Path $env:LOCALAPPDATA 'JudicialAssistantData'

if (-not $Stage2) {
  # نسخ السكربت إلى مجلد مؤقت حتى يمكن حذف مجلد البرنامج وهو يعمل
  $t = Join-Path $env:TEMP 'ja_uninstall.ps1'
  Copy-Item $MyInvocation.MyCommand.Path $t -Force
  Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"' + $t + '"'),'-Stage2')
  exit
}

Add-Type -AssemblyName System.Windows.Forms
$rtl = [System.Windows.Forms.MessageBoxOptions]'RtlReading,RightAlign'
function Ask($msg, $title) {
  return [System.Windows.Forms.MessageBox]::Show($msg, $title, [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question, [System.Windows.Forms.MessageBoxDefaultButton]::Button2, $rtl)
}

$r1 = Ask ('هل تريد إلغاء تثبيت ' + $appName + ' من هذا الكمبيوتر؟') 'إلغاء التثبيت'
if ($r1 -ne [System.Windows.Forms.DialogResult]::Yes) { exit }

$r2 = Ask ('هل تريد أيضاً حذف بياناتك (القضايا والمرفقات) من هذا الكمبيوتر؟' + "`n`n" + 'اختر «لا» للاحتفاظ بها (ستعود كما هي إذا أعدت التثبيت). اختر «نعم» فقط إن كان لديك نسخة احتياطية أو لا تحتاج البيانات.') 'حذف البيانات'
$wipe = ($r2 -eq [System.Windows.Forms.DialogResult]::Yes)

Get-Process -Name 'JudicialAgenda' -ErrorAction SilentlyContinue | Stop-Process -Force
try {
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like '*JudicialAssistantData*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}
Start-Sleep -Seconds 2

$errors = @()
foreach ($d in @($dest, $lite)) {
  if (Test-Path $d) {
    for ($i = 0; $i -lt 5; $i++) {
      try { Remove-Item $d -Recurse -Force -ErrorAction Stop; break } catch { Start-Sleep -Seconds 1 }
    }
    if (Test-Path $d) { $errors += $d }
  }
}
$names = @(($appName + '.lnk'), ('إلغاء تثبيت ' + $appName + '.lnk'), ($appName + ' - إنشاء حزمة تثبيت أوفلاين.lnk'), 'الأجندة القضائية.lnk', 'السكرتير الإلكتروني.lnk', 'إلغاء تثبيت السكرتير الإلكتروني.lnk', 'السكرتير الإلكتروني - إنشاء حزمة تثبيت أوفلاين.lnk')
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  foreach ($n in $names) {
    $p = Join-Path $folder $n
    if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
  }
}
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\JudicialAgenda' -Recurse -Force -ErrorAction SilentlyContinue

if ($wipe) {
  if (Test-Path $liteData) { Remove-Item $liteData -Recurse -Force -ErrorAction SilentlyContinue }
  foreach ($n in @('JudicialAgenda', 'الأجندة القضائية', 'السكرتير الإلكتروني', 'المساعد القضائي الإلكتروني')) {
    $d = Join-Path $env:APPDATA $n
    if (Test-Path $d) { Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue }
  }
}

$msg = 'تم إلغاء تثبيت ' + $appName + '.'
if ($wipe) { $msg += "`nوتم حذف بياناتك." } else { $msg += "`nتم الاحتفاظ ببياناتك، وستجدها كما هي عند إعادة التثبيت." }
if ($errors.Count -gt 0) { $msg += "`n`nتعذر حذف بعض الملفات، احذف هذا المجلد يدوياً:`n" + ($errors -join "`n") }
[void][System.Windows.Forms.MessageBox]::Show($msg, 'إلغاء التثبيت', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information, [System.Windows.Forms.MessageBoxDefaultButton]::Button1, $rtl)
