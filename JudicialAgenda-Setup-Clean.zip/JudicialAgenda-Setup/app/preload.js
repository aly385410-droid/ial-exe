const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('desktop',{
  isDesktop:true,
  run:(c)=>ipcRenderer.invoke('desk',c),
  getInfo:()=>ipcRenderer.invoke('info'),
  setServer:(on)=>ipcRenderer.invoke('server',on),
  setPin:(p)=>ipcRenderer.invoke('pin',p),
  backup:(name,json,keep)=>ipcRenderer.invoke('backup',{name,json,keep}),
  backupDir:(open)=>ipcRenderer.invoke('backupdir',!!open),
  openShare:()=>ipcRenderer.invoke('openshare'),
  ocrFetch:()=>ipcRenderer.invoke('ocrfetch'),
  ocrWin:(data,langs)=>ipcRenderer.invoke('ocrwin',{data,langs}),
  onRequest:(fn)=>ipcRenderer.on('req',(e,id,msg)=>{
    Promise.resolve().then(()=>fn(msg)).then(r=>ipcRenderer.send('res',id,r),err=>ipcRenderer.send('res',id,{status:500,json:{error:String(err)}}));
  })
});
