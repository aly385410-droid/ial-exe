OCR engine folder. lang\*.traineddata.gz = Tesseract fast models (Apache-2.0).
Engine files (tesseract.min.js, worker.min.js, tesseract-core*.wasm.js) are downloaded once by Get-OCR-Engine.bat (internet needed once).
