const {app,BrowserWindow,Menu,shell,ipcMain}=require('electron');
const path=require('path'),os=require('os'),fs=require('fs'),{spawn}=require('child_process');
const makeServer=require('./server.js');
app.setName('المساعد القضائي الإلكتروني');
// تثبيت مكان البيانات على المجلد الأقدم/الأحدث استخداماً حتى لا تضيع بيانات من حدّث من إصدار سابق
(function pinData(){try{const base=app.getPath('appData');let best=null,bt=0;
  for(const n of['الأجندة القضائية','JudicialAgenda','السكرتير الإلكتروني','المساعد القضائي الإلكتروني']){const d=path.join(base,n);
    for(const sub of['Local Storage','IndexedDB']){try{const t=fs.statSync(path.join(d,sub)).mtimeMs;if(t>bt){bt=t;best=d}}catch(e){}}}
  app.setPath('userData',best||path.join(base,'JudicialAgenda'))}catch(e){}})();
if(!app.requestSingleInstanceLock()){app.quit()}
let win=null,server=null,seq=0,curPin='';const pending=new Map();const PORT=8765;
const shareDir=path.join(app.getPath('documents'),'المساعد القضائي - مشاركة');
function ips(){const o=[],n=os.networkInterfaces();for(const k in n)for(const a of(n[k]||[]))if(a.family==='IPv4'&&!a.internal)o.push(a.address);return o}
const info=()=>({on:!!server,ips:ips(),port:PORT,shareDir,ocrFiles:fs.existsSync(path.join(__dirname,'ocr','tesseract.min.js'))&&fs.existsSync(path.join(__dirname,'ocr','worker.min.js'))&&fs.existsSync(path.join(__dirname,'ocr','tesseract-core-simd-lstm.wasm.js'))});
function ask(msg){return new Promise((res,rej)=>{
  if(!win||win.isDestroyed())return rej(new Error('no window'));
  const id=++seq,t=setTimeout(()=>{pending.delete(id);rej(new Error('timeout'))},300000);
  pending.set(id,v=>{clearTimeout(t);res(v)});win.webContents.send('req',id,msg)})}
ipcMain.on('res',(e,id,r)=>{const f=pending.get(id);if(f){pending.delete(id);f(r)}});
function start(){return new Promise(resolve=>{
  if(server)return resolve();
  const s=makeServer(ask,{getPin:()=>curPin,shareDir,appDir:__dirname});
  s.on('error',()=>{server=null;resolve()});
  s.listen(PORT,'0.0.0.0',()=>{server=s;resolve()});
})}
function stop(){if(server){server.close();server=null}}
ipcMain.handle('info',()=>info());
ipcMain.handle('desk',(e,cmd)=>{try{
  const f=path.join(path.dirname(process.execPath),'setup',cmd==='uninstall'?'uninstall.ps1':'make-offline-package.ps1');
  if(!['uninstall','offline'].includes(cmd)||!fs.existsSync(f))return{ok:false};
  spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',f],{detached:true,stdio:'ignore',windowsHide:true}).unref();
  if(cmd==='uninstall')setTimeout(()=>app.quit(),600);
  return{ok:true}}catch(err){return{ok:false}}});
ipcMain.handle('server',async(e,on)=>{if(on)await start();else stop();return info()});
ipcMain.handle('pin',(e,p)=>{curPin=String(p||'');return true});
const bkDir=path.join(app.getPath('documents'),'المساعد القضائي - نسخ احتياطية');
ipcMain.handle('backup',(e,{name,json,keep})=>{try{
  fs.mkdirSync(bkDir,{recursive:true});
  const safe=String(name||'backup.json').replace(/[^\w.\-\u0600-\u06FF]/g,'_');
  const f=path.join(bkDir,safe),tmp=f+'.tmp';
  fs.writeFileSync(tmp,String(json||''),'utf8');fs.renameSync(tmp,f);
  const n=Math.max(3,Math.min(60,+keep||14));
  const all=fs.readdirSync(bkDir).filter(x=>/^agenda-auto-.*\.json$/.test(x)).sort().reverse();
  all.slice(n).forEach(x=>{try{fs.unlinkSync(path.join(bkDir,x))}catch(_){}});
  return{ok:true,dir:bkDir,file:f,count:Math.min(all.length,n)};
}catch(err){return{ok:false,error:String(err&&err.message||err)}}});
ipcMain.handle('backupdir',async(e,open)=>{try{fs.mkdirSync(bkDir,{recursive:true});if(open)await shell.openPath(bkDir);
  const list=fs.readdirSync(bkDir).filter(x=>/\.json$/.test(x)).sort().reverse();return{ok:true,dir:bkDir,list}}catch(err){return{ok:false,error:String(err)}}});
ipcMain.handle('ocrfetch',async()=>{
  const dir=path.join(__dirname,'ocr');
  const base=process.env.OCR_CDN||'https://cdn.jsdelivr.net/npm/';
  const files=[['tesseract.js@5.0.0/dist/tesseract.min.js','tesseract.min.js'],['tesseract.js@5.0.0/dist/worker.min.js','worker.min.js'],['tesseract.js-core@5.0.0/tesseract-core.wasm.js','tesseract-core.wasm.js'],['tesseract.js-core@5.0.0/tesseract-core-simd.wasm.js','tesseract-core-simd.wasm.js'],['tesseract.js-core@5.0.0/tesseract-core-lstm.wasm.js','tesseract-core-lstm.wasm.js'],['tesseract.js-core@5.0.0/tesseract-core-simd-lstm.wasm.js','tesseract-core-simd-lstm.wasm.js']];
  const get=(u,n=0)=>new Promise((res,rej)=>{const m=u.startsWith('https')?require('https'):require('http');
    const q=m.get(u,{headers:{'User-Agent':'JudicialAssistant'}},r=>{
      if([301,302,307,308].includes(r.statusCode)&&r.headers.location&&n<5){r.resume();return res(get(new URL(r.headers.location,u).href,n+1))}
      if(r.statusCode!==200){r.resume();return rej(new Error('HTTP '+r.statusCode))}
      const ch=[];r.on('data',d=>ch.push(d));r.on('end',()=>res(Buffer.concat(ch)));r.on('error',rej)});
    q.on('error',rej);q.setTimeout(90000,()=>q.destroy(new Error('انتهت المهلة')))});
  try{fs.mkdirSync(dir,{recursive:true});
    for(const [pth,name] of files){const f=path.join(dir,name);try{if(fs.statSync(f).size>1000)continue}catch(_){}
      const b=await get(base+pth);fs.writeFileSync(f+'.tmp',b);fs.renameSync(f+'.tmp',f)}
    return{ok:true}}catch(err){return{ok:false,error:String(err&&err.message||err)}}
});
ipcMain.handle('openshare',async()=>{try{fs.mkdirSync(shareDir,{recursive:true});await shell.openPath(shareDir);return true}catch(err){return false}});
// قارئ النصوص المدمج في ويندوز (بدون إنترنت) — يعمل إذا كانت حزمة اللغة العربية/الإنجليزية مثبتة مع ميزة OCR
ipcMain.handle('ocrwin',async(e,{data,langs})=>{
  try{
    const ps1=path.join(__dirname,'ocr-win.ps1');if(!fs.existsSync(ps1))return{ok:false,error:'no-script'};
    const tmp=path.join(os.tmpdir(),'ja_ocr_'+Date.now()+'.png');fs.writeFileSync(tmp,Buffer.from(String(data).replace(/^data:[^,]*,/,''),'base64'));
    const out=await new Promise(res=>{
      const c=spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',ps1,'-Image',tmp,'-Langs',String(langs||'ar,en-US')],{windowsHide:true});
      let o='',er='';c.stdout.on('data',d=>o+=d);c.stderr.on('data',d=>er+=d);
      const to=setTimeout(()=>{try{c.kill()}catch(x){}},120000);
      c.on('close',()=>{clearTimeout(to);res({o,er})});c.on('error',()=>{clearTimeout(to);res({o:'',er:'spawn'})});
    });
    try{fs.unlinkSync(tmp)}catch(x){}
    const j=JSON.parse(out.o.replace(/^\uFEFF/,'').trim()||'{}');
    return j.error?{ok:false,error:j.error,langs:j.langs}:{ok:true,text:j.text||''};
  }catch(err){return{ok:false,error:String(err)}}});
function create(){
  win=new BrowserWindow({width:1366,height:820,minWidth:900,minHeight:600,title:'المساعد القضائي الإلكتروني',
    backgroundColor:'#0a1626',autoHideMenuBar:true,icon:path.join(__dirname,'icon.png'),
    webPreferences:{contextIsolation:true,sandbox:true,spellcheck:false,preload:path.join(__dirname,'preload.js')}});
  Menu.setApplicationMenu(null);
  win.maximize();
  win.loadFile(path.join(__dirname,'index.html'));
  win.webContents.setWindowOpenHandler(({url})=>{
    if(url.startsWith('blob:'))return{action:'allow'};
    if(/^https?:/.test(url))shell.openExternal(url);
    return{action:'deny'};
  });
}
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.focus()}});
app.whenReady().then(()=>{create();app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)create()})});
app.on('window-all-closed',()=>{stop();app.quit()});
