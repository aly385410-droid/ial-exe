@echo off
title Get OCR engine
echo Downloading the OCR engine (internet needed once)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-OCR-Engine.ps1"
echo.
pause
