﻿# Downloads the OCR engine files (once, needs internet)
param([string]$Target = '')
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$targets = @()
$a = Join-Path $here 'app\ocr'; if (Test-Path (Join-Path $here 'app')) { $targets += $a }
$b = Join-Path $here '..\resources\app\ocr'; if (Test-Path (Join-Path $here '..\resources\app')) { $targets += (Resolve-Path (Join-Path $here '..\resources\app')).Path + '\ocr' }
$d = Join-Path $env:LOCALAPPDATA 'Programs\JudicialAgenda\resources\app'; if (Test-Path $d) { $targets += ($d + '\ocr') }
if ($Target) { $targets = @($Target) }
$targets = $targets | Select-Object -Unique
if (-not $targets) { Write-Host 'Application folder not found.'; exit 1 }
$files = @(
 @('https://cdn.jsdelivr.net/npm/tesseract.js@5.0.0/dist/tesseract.min.js','tesseract.min.js'),
 @('https://cdn.jsdelivr.net/npm/tesseract.js@5.0.0/dist/worker.min.js','worker.min.js'),
 @('https://cdn.jsdelivr.net/npm/tesseract.js-core@5.0.0/tesseract-core.wasm.js','tesseract-core.wasm.js'),
 @('https://cdn.jsdelivr.net/npm/tesseract.js-core@5.0.0/tesseract-core-simd.wasm.js','tesseract-core-simd.wasm.js'),
 @('https://cdn.jsdelivr.net/npm/tesseract.js-core@5.0.0/tesseract-core-lstm.wasm.js','tesseract-core-lstm.wasm.js'),
 @('https://cdn.jsdelivr.net/npm/tesseract.js-core@5.0.0/tesseract-core-simd-lstm.wasm.js','tesseract-core-simd-lstm.wasm.js')
)
foreach ($t in $targets) {
  if (-not (Test-Path $t)) { New-Item -ItemType Directory -Path $t | Out-Null }
  foreach ($f in $files) {
    Write-Host ('Downloading ' + $f[1] + ' ...')
    Invoke-WebRequest -Uri $f[0] -OutFile (Join-Path $t $f[1]) -UseBasicParsing
  }
  Write-Host ('OK -> ' + $t)
}
Write-Host 'Done. Restart the application.'
